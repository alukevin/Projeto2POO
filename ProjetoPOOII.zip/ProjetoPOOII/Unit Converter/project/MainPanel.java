package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.List;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MainPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private JTextField 				firstBox;
	private JTextField 				secondBox;
	private JTextField 				inPut;
	private JTextField 				outPut;
	private JComboBox<String>		jComboBox1;
	private JComboBox<String>		jComboBox2;

	MainPanel() {
		super();
		setupFirstBox();
		setupInPut();
		setupComboBox1();
		setupSecondtBox();
		setupOutPut();
		setupComboBox2();
		setupLayOut();

	}
	private void setupFirstBox() {
		firstBox = new JTextField(20);
		firstBox.setBackground(Color.gray);
		firstBox.setBorder(BorderFactory.createEtchedBorder());
		firstBox.setHorizontalAlignment(JTextField.CENTER);
		firstBox.setText("Convert from");
		firstBox.setName("Box1");
		firstBox.setFont(new Font("Serif", Font.BOLD, 22));
		firstBox.setEditable(false);
		firstBox.setBorder(BorderFactory.createEtchedBorder());
		this.add(firstBox);
	}

	private void setupSecondtBox() {
		secondBox = new JTextField(20);
		secondBox.setBackground(Color.gray);
		secondBox.setBorder(BorderFactory.createEtchedBorder());
		secondBox.setHorizontalAlignment(JTextField.CENTER);
		secondBox.setText("to");
		secondBox.setName("Box2");
		secondBox.setFont(new Font("Serif", Font.BOLD, 22));
		secondBox.setEditable(false);
		secondBox.setBorder(BorderFactory.createEtchedBorder());
		this.add(secondBox);
	}
	
	private void setupInPut() {
		inPut = new JTextField(20);
		inPut.setText("Digite um valor:");
		inPut.setBorder(BorderFactory.createEtchedBorder());
		inPut.setHorizontalAlignment(JTextField.RIGHT);
		inPut.setName("Input");
		inPut.setFont(new Font("Serif", Font.BOLD, 22));
		inPut.setBorder(BorderFactory.createEtchedBorder());
		this.add(inPut);
	}
	
	private void setupOutPut() {
		outPut = new JTextField(20);
		outPut.setBorder(BorderFactory.createEtchedBorder());
		outPut.setHorizontalAlignment(JTextField.RIGHT);
		outPut.setEditable(false);
		outPut.setName("output");
		outPut.setFont(new Font("Serif", Font.BOLD, 22));
		outPut.setBorder(BorderFactory.createEtchedBorder());
		this.add(outPut);
	}
	private void setupComboBox1() {
		jComboBox1 = new JComboBox<String>();
		jComboBox1.setName("Combo1");
		jComboBox1.setFont(new Font("Serif", Font.BOLD, 19));
		jComboBox1.addItem("");
		jComboBox1.addItem("item 1");
		jComboBox1.addItem("item 2");
		jComboBox1.addItem("item 3");
		this.add(jComboBox1);
		
	}

	private void setupComboBox2() {
		jComboBox2 = new JComboBox<String>();
		jComboBox2.setName("Combo2");
		jComboBox2.setFont(new Font("Serif", Font.BOLD, 19));
		jComboBox2.addItem("");
		jComboBox2.addItem("item 1");
		jComboBox2.addItem("item 2");
		jComboBox2.addItem("convert to{distance(km)}");
		this.add(jComboBox2);
	}
	/*.addComponent(firstBox)
    .addComponent(inPut)
    .addComponent(jComboBox1)
     .addComponent(secondBox)
     .addComponent(outPut)
     .addComponent(jComboBox2);*/
	
	private void setupLayOut() {
		/*Container contentPane = new Container();
		contentPane.add(this,BorderLayout.PAGE_START);*/

		//layout.setAutoCreateContainerGaps(true);
		//First row
		firstBox.setBounds(10, 25, 250,80);
		inPut.setBounds(265, 25, 250,80);
		jComboBox1.setBounds(520, 25, 400,80);
		
		//Second row
		secondBox.setBounds(10, 110, 250,80);
		outPut.setBounds(265, 110, 250,80);
		jComboBox2.setBounds(520, 110, 400,80);
		//jComboBox2.addActionListener(this);
		//this.setLayout(new GridLayout(2,3,50,80));
		//this.setMaximumSize(getSize());
		this.setLayout(null);
		
	}
	public JTextField getInPut() {
		return inPut;
	}
	public JComboBox<String> getjComboBox1() {
		return jComboBox1;
	}
	public JTextField getOutPut() {
		return outPut;
	}
	public JComboBox<String> getjComboBox2() {
		return jComboBox2;
	}
}